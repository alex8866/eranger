"""This package includes container-objects for managing stored data"""
